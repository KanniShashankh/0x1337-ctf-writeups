# TinyCPU-2 secure boot

Our secure-boot chip runs `chall.hex`: it decrypts a boot phrase from data
memory, and when the boot phrase comes out correctly the chip rewards you.
`chall.hex` worked perfectly in our instruction-set emulator. On the real
silicon it prints garbage and refuses to boot. Make it boot on the real chip.

You get the cpu schema 

The datasheet below documents the *intended* ISA -- but the hardware
is what actually runs, and hardware is truth.

You may need to install iverilog to run this.

## Running the chip
    cp chall.hex prog.hex          # the chip loads prog.hex and data.hex
    vvp -n cpu

Write your own program into `prog.hex`: one 16-bit hex word per line, no `0x`
prefix, `//` comments allowed. Up to 32 words; any you leave out read as `0000` (HALT).
It's a gate-level simulation, so give it a moment: a short program runs in a few
seconds, and a program that runs into the 40000-cycle watchdog can take up to a minute.

## Machine
8 registers r0-r7 (8-bit, start at 0). 5-bit PC (so imem wraps at 32).
32 words of 16-bit instruction memory. 256 bytes of data memory.
r7 is special: the boot checker watches everything written to it.

Encoding: `[15:12] op  [11:9] rd  [8:6] rs1  [5:3] rs2`,
`[7:0] imm8` (LI, JMP), `[5:0] off6` signed PC-relative (BNE).

| op | mnemonic | datasheet says |
|----|----------|----------------|
| 0 | HALT | stop and run the boot check |
| 1 | LI rd, imm8 | rd = imm8 |
| 2 | ADD rd, rs1, rs2 | rd = rs1 + rs2 |
| 3 | SUB rd, rs1, rs2 | rd = rs1 - rs2 |
| 4 | XOR rd, rs1, rs2 | rd = rs1 ^ rs2 |
| 5 | AND rd, rs1, rs2 | rd = rs1 & rs2 |
| 6 | LD rd, [rs1] | rd = dmem[rs1] |
| 7 | ST [rs1], rs2 | dmem[rs1] = rs2 |
| 8 | BNE rd, rs1, off6 | if rd != rs1: pc += off6 |
| 9 | JMP imm8 | pc = imm8 |
| A | OUT rs1 | print rs1 as ASCII |
| B | NOP | do nothing |