# Gate-Level Netlist Challenge

You are given an anonymous gate-level Verilog netlist (`netlist.v`). 
The module accepts a 15-byte serial input on `data_in` (sampled when `valid=1` on the rising edge of `clk`). 
Pulse `rst` high for at least 1 cycle to initialize the circuit, then feed it 15 bytes sequentially. 
If your 15-byte sequence matches the secret embedded in the logic, the `unlocked` pin will go HIGH. 
Find the correct 15 bytes (which is the ASCII flag) and submit it.
