White-box source for the custom plugin. wpscan will find nothing — audit this.
See /wp-json/ and the Library page after registering.
