=== Deccan Library ===
Contributors: libraryit
Stable tag: 1.0.6
Requires at least: 6.0
Tested up to: 6.8

Internal catalog preview widget. Shortcode: [deccan_library]
