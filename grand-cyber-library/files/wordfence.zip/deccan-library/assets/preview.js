async function deccanPreview() {
  const id = document.getElementById('deccan-id').value || DECCAN.mine;
  const u = new URL(DECCAN.ajax);
  u.searchParams.set('action', 'deccan_preview');
  u.searchParams.set('id', id);
  u.searchParams.set('nonce', DECCAN.nonce);
  const r = await fetch(u, { credentials: 'same-origin' });
  document.getElementById('deccan-out').textContent =
    r.status + ' ' + (await r.text()).slice(0, 2000);
}
