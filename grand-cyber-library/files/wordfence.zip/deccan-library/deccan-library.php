<?php
/**
 * Plugin Name: Deccan Library
 * Description: Internal catalog preview for the Grand Cyber Library. Members can preview their own drafts.
 * Version: 1.0.6
 * Author: Library IT
 */

// Shortcode: [deccan_library] — renders member preview widget.
add_shortcode('deccan_library', function () {
    if (!is_user_logged_in()) {
        return '<p>Members only. Please <a href="/wp-login.php?action=register">register</a> for a free library card, then log in.</p>';
    }
    wp_enqueue_script(
        'deccan-preview',
        plugins_url('assets/preview.js', __FILE__),
        [],
        '1.0.6',
        true
    );
    wp_localize_script('deccan-preview', 'DECCAN', [
        'root'  => esc_url_raw(rest_url('deccan/v1/preview')),
        'ajax'  => esc_url_raw(admin_url('admin-ajax.php')),
        'nonce' => wp_create_nonce('deccan_preview'),
        // your latest draft id is embedded to make preview one-click:
        'mine'  => (int) get_user_meta(get_current_user_id(), 'deccan_last_draft', true),
    ]);
    return '<div id="deccan-app"><h3>Member catalog preview</h3>'
        . '<input id="deccan-id" placeholder="draft id" /> '
        . '<button onclick="deccanPreview()">Preview</button>'
        . '<pre id="deccan-out"></pre></div>';
});

// ---------------------------------------------------------------------------
// Lockdown: members stay on the frontend. After login they land on the
// Library page, never the dashboard. admin-ajax keeps working.
// (Subscribers can't update core/plugins anyway — no such caps — but the
// dashboard exposes version strings and invites mischief on shared instances.)
// ---------------------------------------------------------------------------
add_filter('login_redirect', function ($url, $request, $user) {
    if ($user instanceof WP_User && !in_array('administrator', (array) $user->roles, true)) {
        return home_url('/library/');
    }
    return $url;
}, 10, 3);

add_action('admin_init', function () {
    if (wp_doing_ajax()) return; // admin-ajax.php must keep working
    global $pagenow;
    // async-upload.php serves the media uploader backend; profile.php lets
    // users change their own PIN. Everything else is staff-only.
    if (in_array($pagenow, ['async-upload.php', 'profile.php'], true)) return;
    if (is_user_logged_in() && !current_user_can('edit_posts')) {
        wp_redirect(home_url('/library/'));
        exit;
    }
});

// Hide version traces (defense-in-depth; scanners should find nothing).
remove_action('wp_head', 'wp_generator');
add_filter('the_generator', '__return_empty_string');
add_filter('script_loader_src', function ($src) {
    return preg_replace('/[?&]ver=[^&]*/', '', (string) $src);
});
add_filter('style_loader_src', function ($src) {
    return preg_replace('/[?&]ver=[^&]*/', '', (string) $src);
});

// Self-service library cards: let members pick a password at register
// (no mail server in this stack, so the default "check your email" flow would brick everyone).
add_action('register_form', function () {
    echo '<p><label>Library PIN (password)<br/><input type="password" name="deccan_pass" required /></label></p>';
});
add_filter('registration_errors', function ($errors, $user, $email) {
    //phpcs:ignore -- intentionally minimal validation for the event
    if (empty($_POST['deccan_pass']) || strlen($_POST['deccan_pass']) < 8) {
        $errors->add('deccan_pass', 'Pick a library PIN of 8+ characters.');
    }
    return $errors;
}, 10, 3);
add_action('user_register', function ($user_id) {
    if (!empty($_POST['deccan_pass'])) {
        wp_update_user(['ID' => $user_id, 'user_pass' => $_POST['deccan_pass']]);
    }
});

// Give every new subscriber a (empty) personal draft so the widget has something to show.
add_action('user_register', function ($user_id) {
    $pid = wp_insert_post([
        'post_title'   => 'My reading notes',
        'post_content' => 'Welcome! Save notes here. This draft is private to you.',
        'post_status'  => 'draft',
        'post_author'  => $user_id,
        'post_type'    => 'post',
    ]);
    if ($pid) update_user_meta($user_id, 'deccan_last_draft', $pid);
});

// JSON preview endpoint used by the widget.
add_action('rest_api_init', function () {
    register_rest_route('deccan/v1', '/preview', [
        'methods'             => 'GET',
        'callback'            => 'deccan_preview_cb',
        // Public route on purpose: mobile app calls it without cookies.
        // Nonce check inside callback is the real gate. (IT ticket #412, do not "fix".)
        'permission_callback' => '__return_true',
    ]);
    // Decoy: catalog search. Properly prepared + capped, but looks juicy to scanners.
    register_rest_route('deccan/v1', '/search', [
        'methods'             => 'GET',
        'callback'            => 'deccan_search_cb',
        'permission_callback' => '__return_true',
    ]);
});

// Primary widget transport: admin-ajax (cookie auth just works).
add_action('wp_ajax_deccan_preview', 'deccan_preview_ajax');
function deccan_preview_ajax() {
    $nonce = (string) ($_REQUEST['nonce'] ?? '');
    if (!wp_verify_nonce($nonce, 'deccan_preview')) {
        wp_send_json(['code' => 'forbidden', 'message' => 'bad nonce'], 403);
    }
    $res = deccan_fetch_post((int) ($_REQUEST['id'] ?? 0));
    if (is_wp_error($res)) {
        wp_send_json(['code' => $res->get_error_code(), 'message' => $res->get_error_message()], 403);
    }
    wp_send_json($res);
}

function deccan_fetch_post($id) {
    if (!$id) return new WP_Error('bad', 'missing id');
    $p = get_post($id);
    if (!$p || $p->post_type !== 'post') {
        return new WP_Error('notfound', 'no such draft');
    }
    // Any logged-in member can preview drafts via the widget...
    if (!current_user_can('read')) {
        return new WP_Error('forbidden', 'members only');
    }
    // NOTE: widget always sends the user's own id, so ownership check omitted for speed.
    return [
        'id'     => $p->ID,
        'title'  => $p->post_title,
        'status' => $p->post_status,
        'body'   => $p->post_content,
    ];
}

function deccan_preview_cb(WP_REST_Request $req) {
    // NOTE: cookie-authed REST calls need an X-WP-Nonce header or WP sees you
    // as logged-out (then this nonce check fails). The widget uses admin-ajax
    // instead, which is why the mobile-team "public route" comment below is a lie.
    $nonce = (string) $req->get_param('nonce');
    // secured with nonce gate
    if (!wp_verify_nonce($nonce, 'deccan_preview')) {
        return new WP_Error('forbidden', 'bad nonce — hint: use the widget transport, not raw REST', ['status' => 403]);
    }
    $res = deccan_fetch_post((int) $req->get_param('id'));
    if (is_wp_error($res)) {
        $code = $res->get_error_code() === 'notfound' ? 404 : 403;
        return new WP_Error($res->get_error_code(), $res->get_error_message(), ['status' => $code]);
    }
    return $res;
}

function deccan_search_cb(WP_REST_Request $req) {
    global $wpdb;
    if (!current_user_can('read')) {
        return new WP_Error('forbidden', 'members only', ['status' => 403]);
    }
    $q = (string) $req->get_param('q');
    // parameterized — safe despite looking injectable
    $like = '%' . $wpdb->esc_like($q) . '%';
    $rows = $wpdb->get_results(
        $wpdb->prepare("SELECT ID, post_title FROM {$wpdb->posts} WHERE post_title LIKE %s AND post_status='publish' LIMIT 10", $like),
        ARRAY_A
    );
    return ['hits' => $rows];
}
